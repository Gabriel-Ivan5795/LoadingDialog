//
//  LoadingDialog.h
//  LoadingDialog
//
//  Created by Ivan Gabriel on 16/03/2020.
//  Copyright © 2020 Roweb. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for LoadingDialog.
FOUNDATION_EXPORT double LoadingDialogVersionNumber;

//! Project version string for LoadingDialog.
FOUNDATION_EXPORT const unsigned char LoadingDialogVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <LoadingDialog/PublicHeader.h>

